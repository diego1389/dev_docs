﻿Public Class lampara
    Public Property nombre As String
    Public Property fotones As Double
    Public Property x As Integer
    Public Property y As Integer
End Class
