﻿Public Class cliente
    Public Shared Sub Display(s As String, c As IComponent)
        Console.WriteLine(s + c.operacion)
    End Sub

End Class



