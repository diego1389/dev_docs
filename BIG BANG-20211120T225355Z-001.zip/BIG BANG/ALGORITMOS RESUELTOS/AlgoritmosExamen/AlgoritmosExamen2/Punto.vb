﻿Public Class Punto
    Public Property x As Integer
    Public Property y As Integer

End Class
