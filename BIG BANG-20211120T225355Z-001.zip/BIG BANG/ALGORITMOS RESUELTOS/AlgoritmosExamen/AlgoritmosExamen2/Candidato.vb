﻿Public Class Candidato
    Public Property nombre As String
    Public Property puntaje As Integer
End Class
