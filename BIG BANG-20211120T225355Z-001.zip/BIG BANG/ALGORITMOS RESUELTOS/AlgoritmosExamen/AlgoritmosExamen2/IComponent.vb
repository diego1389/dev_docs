﻿Public Interface IComponent
    Function operacion() As String
End Interface
