﻿Public Class NodoGrafo
    Public Property valor As Integer
    Public Property listaNodos As New List(Of NodoGrafo)
End Class
