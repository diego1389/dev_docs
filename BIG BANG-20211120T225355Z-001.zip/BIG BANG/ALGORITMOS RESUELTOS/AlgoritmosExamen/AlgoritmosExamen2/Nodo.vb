﻿Public Class Nodo
    Public Property izquierda As Nodo
    Public Property derecha As Nodo
    Public valor As Integer
End Class
