﻿Imports AlgoritmosExamen2

Public Class Triangulo
    Implements IDibujar

    Public Function dibujar() Implements IDibujar.dibujar
        Return "Yo dibujo de color"
    End Function
End Class
