﻿Public Class Rectangulo
    Public Property superiorIzq As Punto
    Public Property superiorDer As Punto

End Class
