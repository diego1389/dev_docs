﻿Public Interface IConexion
    Sub conecta()
    Sub cierraConexion()

    Sub ejecutarSP(sp As String)
End Interface
