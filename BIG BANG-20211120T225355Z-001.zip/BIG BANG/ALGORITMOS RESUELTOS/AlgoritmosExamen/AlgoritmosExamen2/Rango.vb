﻿Public Class Rango
    Public Property vectorNombre As String = ""
    Public Property valor As Integer = 0
End Class
