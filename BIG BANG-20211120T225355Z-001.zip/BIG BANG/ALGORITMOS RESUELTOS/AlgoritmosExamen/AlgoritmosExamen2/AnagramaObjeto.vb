﻿Public Class AnagramaObjeto
    Public Property letra As String
    Public Property cantidadLetras As Integer
End Class
