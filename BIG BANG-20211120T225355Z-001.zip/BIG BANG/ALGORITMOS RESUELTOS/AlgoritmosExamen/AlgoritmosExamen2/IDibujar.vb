﻿Public Interface IDibujar
    Function dibujar()
End Interface
