﻿Public Class Detector
    Public Property intensidad As Double
    Public Property x As Integer
    Public Property y As Integer
    Public Property nombre As String
End Class
