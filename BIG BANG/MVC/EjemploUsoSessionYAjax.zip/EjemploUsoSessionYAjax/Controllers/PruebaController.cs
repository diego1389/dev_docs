﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EjemploUsoSessionYAjax.Models;


namespace EjemploUsoSessionYAjax.Controllers
{
    public class PruebaController : Controller
    {

        private List<Models.Item> Items
        {
            get
            {
                if(System.Web.HttpContext.Current.Session["LISTA"] == null)
                {
                    System.Web.HttpContext.Current.Session.Add("LISTA", new List<Item>());
                }
                return  (List<Item>) System.Web.HttpContext.Current.Session["LISTA"];
            }
        }

        // GET: Prueba
        public ActionResult Index()
        {
            ViewBag.Items = ObtenerItems();
            return View();
        }

        [HttpPost]  
        public ActionResult Finalizar()
        {
            List<Item> itemsGuardados = Items;
            return RedirectToAction("Index","Home");
        }

        [HttpPost]
        public JsonResult ListarItems()
        {
            return Json(Items);
        }

        [HttpPost]
        public void GuardarItem(int id, string nombre)
        {
            Models.Item item = new Models.Item() ;
            item.id = id;
            item.nombre = nombre;

            Items.Add(item);
        }

        private List<Item> ObtenerItems()
        {
            List<Item> listaInicial = new List<Item>();

            for (int i = 0; i < 10; i++)
            {
                Item item = new Item();
                item.id = i;
                item.nombre = "Item_" + i.ToString();
                listaInicial.Add(item);
            }

            return listaInicial;
        }
    }
}